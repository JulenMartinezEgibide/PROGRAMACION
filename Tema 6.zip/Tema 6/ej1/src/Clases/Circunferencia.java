package Clases;

public class Circunferencia {
    private float radio;

    public Circunferencia() {

    }

    public Circunferencia(float radio) {
        this.radio = radio;
    }

    public float getRadio() {
        return radio;
    }

    public void setRadio(float radio) {
        this.radio = radio;
    }
}
