package Excepciones;

public class CodPostalNoValido {
}
