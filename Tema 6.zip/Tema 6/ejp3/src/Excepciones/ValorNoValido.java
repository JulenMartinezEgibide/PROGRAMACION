package Excepciones;

public class ValorNoValido {
}
