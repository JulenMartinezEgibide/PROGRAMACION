package Excepciones;

public class CodPostalNoValido extends Exception{

}
