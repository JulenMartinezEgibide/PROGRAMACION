package Excepciones;

public class FechaNoValida extends Exception{

}
