package Excepciones;

public class ValorNoValido extends Exception{

}
