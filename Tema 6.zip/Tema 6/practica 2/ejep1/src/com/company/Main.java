package com.company;


import Clases.Estudio;

public class Main {


    public static void main(String[] args) {
        Estudio aEstudio[] = new Estudio[3];
        aEstudio[0] =new Estudio("Disney","Paris","www.Disney.com",19/12/1792,"Francia","945010101 y 945010102");
    }


}
