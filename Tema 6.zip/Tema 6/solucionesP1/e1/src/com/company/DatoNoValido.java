package com.company;

public class DatoNoValido extends Exception{
}
